import csv
import pandas as pd

# make a function to read the data
def load_data():
    # read the csv as dataframe and add headlines
    data=pd.read_csv("hn_stories.csv",names=["submission_time", "upvotes", "url", "headline"])
    #data.columns=["submission_time", "upvotes", "url", "headline"]
    #print(data.head(3))
    # return data
    return data



# sos Function definitions should come before the if __name__ == "__main__" line. These functions  can be imported from other files.

if __name__=="__main__":
    load_data()


    

