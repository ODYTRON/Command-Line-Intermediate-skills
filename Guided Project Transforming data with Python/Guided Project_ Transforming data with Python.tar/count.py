# import the appropriate libraries
import read
import collections

# create a dataframe by calling the function from the read.py file
df=read.load_data()
# create an empty string to use it later
final_string=""
# iterate through rows of the dataframe
for index, row in df.iterrows():
    # as the loop iterates add the headline as string  for each row in the var empty string
    final_string+=str(row["headline"])
# make lower case all the letters of the final string     
final_string=final_string.lower()
# split this long string into  words
words = final_string.split(" ")
# use Counter class to count the 100 words that occure the most  in the data
hundred_words=collections.Counter(words).most_common(100)
print(hundred_words)


