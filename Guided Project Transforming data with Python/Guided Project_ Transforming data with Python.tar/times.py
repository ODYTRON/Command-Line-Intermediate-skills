# import libraries
import read
import collections
from dateutil.parser import parse 

# create a dataframe from the read.py file by calling load_data function
df=read.load_data()
# make an empty string to store time
time_string=""
# make an empty string to store spaces between times
empty_string=" "
# make an empty string to isolate hour
hour_val=""
# iterate through dataframe (notice that we have also an index now apart from rows
for index, row in df.iterrows():
    # in the time string we store the submission_time as a string by using the parse function of       # the parsermodule in dateutil
    time_string=parse(str(row["submission_time"]))
    # now we stote in hour_val the first hour val and every next by using hour property on the         # time_string var and by adding a space with var empty string
    hour_val=hour_val+str(time_string.hour)+empty_string
# then we split these values into words    
words = hour_val.split(" ")
# we use the Counter class to to count most common words
hundred_hour=collections.Counter(words).most_common(100)
# print them
print(hundred_hour)



# You can repeat this procedure to find how many articles were submitted on each day of the month, # year, minute, day of the week, and so on.