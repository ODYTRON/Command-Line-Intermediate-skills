# import libraries
import read
import collections

# create a dataframe
df=read.load_data()
# make an empty string to save domains
domain_string=""
# make an empty string with a space to use it in order to add space for every next url
empty_string=" "
# iterate through the dataframe rows
for index, row in df.iterrows():
    #save in the domain string var the first record and every next with the empty string as a space     #between them
    domain_string=domain_string+str(row["url"])+empty_string
# then take the domain string anb split it by spaces to make a list    
words = domain_string.split(" ")
# make thhe empty list to store the words for letter manipulation
new_words=[]
## Remove nan (not include nan in results)
for value in words:
    # if value is 'nan' pass it
    if value=='nan':
        pass
    # else append this value in the empty list new_words
    else:
        new_words.append(value)

# use the Counter class to count the 100 most common words
hundred_domains=collections.Counter(new_words).most_common(100)
# pr
print(hundred_domains)